package org.example.liberty.client;

import org.example.liberty.service.HelloWorld;

public class HelloClient implements Runnable{
	
	HelloWorld service;
	boolean serviceActive = true;
	Thread clientThread = new Thread(this);
	boolean shutdown = false;
	public void setHelloWorld(HelloWorld hw){
		service = hw;
	}
	
/*	public void bindService(HelloWorld hw){
		if (null != hw){
			serviceActive = true;
		}
	}
	
	public void unbindService(HelloWorld hw){
		if (null != hw){
			serviceActive = false;
		}
	}*/
	
	public void init(){
		clientThread.setDaemon(true);
		clientThread.setName("HelloClient");
		clientThread.start();
	}
	
	public void destroy(){
		shutdown = true;
		clientThread.interrupt();
	}

	@Override
	public void run() {
		while(! shutdown){
			try{
				Thread.sleep(10000);
				if (serviceActive){
					System.out.println("Service says: " + service.getHello());
				}
				else{
					System.out.println("HelloService not active");
				}
			}
			catch (InterruptedException ie){
				
			}
		}
		
	}

}
