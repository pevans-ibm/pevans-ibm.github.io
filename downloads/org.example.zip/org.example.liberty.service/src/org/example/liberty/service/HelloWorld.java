package org.example.liberty.service;

public interface HelloWorld {
	
	public String getHello();

}
