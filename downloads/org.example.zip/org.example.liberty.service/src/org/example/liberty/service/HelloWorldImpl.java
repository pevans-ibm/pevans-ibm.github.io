package org.example.liberty.service;

public class HelloWorldImpl implements HelloWorld {

	@Override
	public String getHello() {
		return "Hello";
	}

}
