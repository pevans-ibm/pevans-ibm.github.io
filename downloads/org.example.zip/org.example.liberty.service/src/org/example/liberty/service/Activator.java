package org.example.liberty.service;

import java.util.Hashtable;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;

public class Activator implements BundleActivator {

	private static BundleContext context;
	ServiceRegistration<?> registration;
	
	static BundleContext getContext() {
		return context;
	}

	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext bundleContext) throws Exception {
		Activator.context = bundleContext;
		Hashtable<String,String> metadata = new Hashtable<String,String>();
		metadata.put("service.description","Example hello Liberty SPR Blueprint Service");
		metadata.put("service.vendor", "example.org");
		String[] interfaces = {HelloWorld.class.getName()};
		registration = context.registerService(interfaces, new HelloWorldImpl(), metadata);
		System.out.println("HelloWorld service registered to OSGi");
	}

	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext bundleContext) throws Exception {
		Activator.context = null;
		registration.unregister();
	}

}
